package Collegeessentials;

public class Supplies {
    int howmany;
    String name;
    String items;
    boolean readyforschool;
    int textbooks;
    int devices;
    int notebooks;

}
