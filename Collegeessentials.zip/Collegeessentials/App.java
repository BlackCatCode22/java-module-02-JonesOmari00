package Collegeessentials;

public class App {
    public static void main(String[] args) {
         Supplies mysupplies = new Supplies();

         mysupplies.devices = 1;
         mysupplies.notebooks = 4;
         mysupplies.textbooks = 3;
         mysupplies.howmany = 10;
         mysupplies.readyforschool = true;
         mysupplies.name = "pencil, pens, notebooks, computer, highlighters, and homework";

         System.out.println(mysupplies.readyforschool);
         System.out.println(mysupplies.devices);
         System.out.println(mysupplies.notebooks);
         System.out.println(mysupplies.textbooks);
         System.out.println(mysupplies.howmany);
         System.out.println(mysupplies.name);

         System.out.println(" These are my college supplies" + mysupplies.name);
         System.out.println("This is my OOP demo practice");
    }
}
